/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finalproyect.dataestructure;

import LISTAS_CIRCULARES.*;

/**
 *
 * @author User
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginInterface interfacejuego = new LoginInterface();
        interfacejuego.setVisible(true); 
        
        
//        Lista lis = new Lista();
//        Ingredientes ing =new Ingredientes();
//        
//        lis.inserta(new Ingredientes(1,ing.IngredienteAleatorio()));
//        lis.inserta(new Ingredientes(2,ing.IngredienteAleatorio()));
//        lis.inserta(new Ingredientes(3,ing.IngredienteAleatorio()));
//        lis.inserta(new Ingredientes(4,ing.IngredienteAleatorio()));
//        lis.inserta(new Ingredientes(5,ing.IngredienteAleatorio()));
//
//        Ingredientes ingAux;
//        
//        if(elimina)
//        {
//            if(buscar()){
//                modifica()
//            }
//                
//        }
        
        
        
        
        
        
        
        
        
        
        
//        System.out.println(lis);
//        
//        
//        System.out.println("---------------------------");
//        
//        lis.mueveIzq();
//        
//        System.out.println(lis); 
//        
//        System.out.println("---------------------------");
//        
//        lis.mueveIzq();
//        
//        System.out.println(lis);
//        System.out.println("---------------------------");
//        
//        lis.mueveIzq();
//        
//        System.out.println(lis);
//        System.out.println(lis);
//        System.out.println("---------------------------");
//        
//        lis.mueveIzq();
//        
//        System.out.println(lis);
//        System.out.println(lis);
//        System.out.println("---------------------------");
//        
//        lis.mueveIzq();
//        
//        System.out.println(lis);
        
        
    }
    
}
