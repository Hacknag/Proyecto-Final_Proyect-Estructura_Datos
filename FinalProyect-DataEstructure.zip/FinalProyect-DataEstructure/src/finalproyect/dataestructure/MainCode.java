/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalproyect.dataestructure;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Arman
 */
public class MainCode {

    public void AboutApp() {
        JOptionPane.showConfirmDialog(null, "WcDonald's App para la"
                + " gestion de inventario del restaurante."
                + "\n\nEsta aplicacion fue diseñada por Armando Aguilar Herrera"
                + " y Estefani Barrantes Angulo para el proyecto final\nde "
                + "investigacion del curso de Estructura de Datos."
                + "\n\nVersion 1.0.0.\n\nTodos los derechos de autor son "
                + "reservados para Armando Aguilar Herrera y Estefani Barrantes"
                + " Angulo.", "Sobre la app",
                JOptionPane.DEFAULT_OPTION);
    }
    
    

}
